### Email (Gmail)
USER_EMAIL_PROVIDER = 'gmail'
USER_NAME = 'FuadBotz'
USER_EMAIL = 'fuadbotz01@gmail.com'
USER_APP_PASSWORD = 'rmqfroxvahkiucqd'

### Neoxr API : https://api.neoxr.my.id
API_KEY = 'sokAXL'

### Open AI : https://beta.openai.com/account/api-keys
OPENAI_API_KEY = ''

### Database : https://www.mongodb.com/
DATABASE_URL = ''

### Chatbot (Auto Reply) : https://brainshop.ai/
BRAIN_API_ID = 172389
BRAIN_API_SECRET = 'ryw2Ek6jmPvDbgL6'

### Anti Porn : https://api.sightengine.com
API_USER = ''
API_SECRET = ''

### Audio Transcription (Whisper) : https://replicate.com/account/api-tokens
REPLICATE_API_TOKEN = ''